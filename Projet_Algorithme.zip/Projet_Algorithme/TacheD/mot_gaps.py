
def mot_gaps(k:int)->list[str]:
    s = ''
    for i in range(k):
        s = s+"-"
    return s