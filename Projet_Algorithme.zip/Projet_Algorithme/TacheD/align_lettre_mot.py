def align_lettre_mot(x,y):
    